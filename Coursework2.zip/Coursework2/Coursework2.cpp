// Coursework2.cpp : This file contains the 'main' function. Program execution begins and ends there.
// pipe client http://www.cplusplus.com/forum/general/139656/
// pause http://www.cplusplus.com/forum/beginner/27291/


#include "Main.h"


int main()
{
	start();

	return 0;
}

