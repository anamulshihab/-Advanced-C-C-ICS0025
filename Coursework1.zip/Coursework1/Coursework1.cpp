// Coursework1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu


#include "Main.h"
#include "Item.h"


int main()
{
	start();
	return 0;
}