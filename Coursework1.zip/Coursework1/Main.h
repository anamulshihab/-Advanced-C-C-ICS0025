#pragma once

#include "Date.h"
#include <map>
#include <vector>
#include <list>
#include <string>
#include <random>
#include <stdexcept>
#include <iostream>
#include <fstream>
#include <functional>
#include <algorithm>
#include <windows.h> 
#include <chrono>
#include <thread>
#include <future>


using namespace std;

void CheckInputError();

void start();













